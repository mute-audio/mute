#!/bin/bash

# +         +
#   m u t e    Installer shell
# +         +
#
# (C)2026 kitamura_design <kitamura_design@me.com>

# Check current OS Codename
OS_codename=$(lsb_release -a |  grep Codename | cut -f 2)

if [ ${OS_codename} = "buster" ] || [ ${OS_codename} = "bullseye" ]; then  # In case of Buster, Bullseye etc.
   bootDIR="boot"
else
   bootDIR="boot/firmware"
fi

set -e
VER=$(cat ./www/cgi-bin/etc/mute.conf | grep ver | cut -d "=" -f 2)

echo ''
echo ' +         +'
echo '   m u t e    RPi-Audio/ MPD Dashboard'
echo " +         +  ver.${VER}"
echo ''
echo " Installer shell for ver.${VER}"
echo ' ©2026 kitamura_design <kitamura_design@me.com>'
echo ''
echo ' PROCEDURES'
echo ''
echo ' 1 - Install lighttpd (Web Server middle-ware)'
echo ' 2 - User group & Permission settings'
echo ' 3 - Enable CGI'
echo ' 4 - Install dependencies - nkf, lsof, bc, pmount, getcover'
echo ' 5 - Install Media Renderers (DLNA & AirPlay)'
echo ' 6 - Copy [ mute ] source'
echo ' 7 - Finalize - Clean up the sources and this script'
echo ''

if [ "$1" = "-y" ]; then
  yn=y

else
  read -p " Are you ready? (Y/n): " yn

fi

case "$yn" in
  ( [yY] ) echo "" ; ;;
  ( [nN] ) echo " Install canceled." ; echo "" ; exit ;;
  ( * ) echo "" ;  ;;
esac

DATE=$(date)

echo " -------- mute install Starts  ${DATE} --------" | sudo tee -a /${bootDIR}/mute_log > /dev/null

#### lightttpd install 	###############################

echo ' 1 - Install lighttpd (Web Server middle-ware)' | sudo tee -a /${bootDIR}/mute_log

set +e

CHK_lighttpd=$(dpkg -l | grep lighttpd | head -n 1 | cut -d " " -f3)

set -e

if [ "$CHK_lighttpd" = "lighttpd" ]; then

	echo " lighttpd is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
	echo " Updating the package index files..."
	sudo apt clean && sudo apt update
	wait
	echo " Updating the package index files... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
    echo ''

	echo " Installing lighttpd..."
	sudo apt -o Acquire::Retries=3 -y -q install lighttpd
	wait
    echo " Installing lighttpd... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
	echo ''

    ## lighttpd trixie support (1.12.0)
	if [ ${OS_codename} = "trixie" ]; then
	    sudo cp ./lighttpd.service /etc/systemd/system/multi-user.target.wants/lighttpd.service
	fi

	## Activate streaming (1.12.0)
	sudo sed -i -e '/server.port.*= */a server.stream-response-body = 1' /etc/lighttpd/lighttpd.conf

	echo " Starting & Enabling lighttpd..."
	sudo systemctl daemon-reload
	sudo systemctl enable --now lighttpd | sudo tee -a /${bootDIR}/mute_log
	wait
fi

#### User group & Permission setting	 ##############

echo ''
echo ' 2 - User Group & Permission settings' | sudo tee -a /${bootDIR}/mute_log

set +e

CHK_groups_audio=$(groups www-data | grep --only-matching audio)

set -e

if [ "$CHK_groups_audio" = "audio" ]; then

	echo " Checking User group  -- OK." | sudo tee -a /${bootDIR}/mute_log
else
	echo " Changing User group setting..."
	sudo gpasswd -a www-data audio  | sudo tee -a /${bootDIR}/mute_log
        echo " Changing User group setting... Done"  | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

set +e

CHK_groups_sudo=$(sudo cat /etc/sudoers | grep www-data | grep --only-matching "NOPASSWD: ALL")

set -e

if [ "$CHK_groups_sudo" = "NOPASSWD: ALL" ]; then
        echo " Checking Permission -- OK." | sudo tee -a /${bootDIR}/mute_log
else
	echo " Changing Permission setting..."
	echo "www-data ALL=(ALL) NOPASSWD: ALL" | sudo tee -a /etc/sudoers  > /dev/null
fi

#### Enable CGI		 #############################
echo ''
echo ' 3 - Enable CGI'  | sudo tee -a /${bootDIR}/mute_log

set +e

CHK_cgi_active=$(ls /etc/lighttpd/conf-enabled | grep 10-cgi.conf)

set -e

if [ "$CHK_cgi_active" = "10-cgi.conf" ]; then

	echo " CGI already activated. Installer will skip this process.."  | sudo tee -a /${bootDIR}/mute_log

else
	echo " Enabling CGI..."

	sudo lighttpd-enable-mod cgi | sudo tee -a /${bootDIR}/mute_log > /dev/null
	wait

	{
	echo '# /usr/share/doc/lighttpd/cgi.txt'
	echo ''
	echo 'server.modules += ( "mod_cgi" )'
	echo ''
	echo '$HTTP["url"] =~ "^/cgi-bin/" {'
	echo '	alias.url += ( "/cgi-bin/" => "/var/www/cgi-bin/" )'
	echo '	cgi.assign = ( ".cgi" => "/usr/bin/bash" )'
	echo '}'
	echo ''
	echo '## Warning this represents a security risk, as it allow to execute any file'
	echo '## with a .pl/.py even outside of /usr/lib/cgi-bin.'
	echo '#'
	echo '#cgi.assign      = ('
	echo '#       ".pl"  => "/usr/bin/perl",'
	echo '#       ".py"  => "/usr/bin/python",'
	echo '#)'
	} | sudo tee /etc/lighttpd/conf-enabled/10-cgi.conf > /dev/null

	wait

	sudo service lighttpd force-reload
	wait

	echo ''
	echo " Restarting lighttpd to activate CGI..."

	sleep 3
	sudo systemctl restart lighttpd
	wait
        echo " Restarting lighttpd to activate CGI... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### Install dependencies 	####################

echo ''
echo ' 4 - Install dependencies - nkf, lsof, bc, pmount, getcover'  | sudo tee -a /${bootDIR}/mute_log

#### nkf ####
set +e

CHK_nkf=$(dpkg -l | grep nkf | head -n 1 | cut -d " " -f3)

set -e

if [ "$CHK_nkf" = "nkf" ]; then
        echo " nkf is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
	echo ''
	echo " Installing nkf..."
	sudo apt -o Acquire::Retries=3 install -y -q nkf
	wait
        echo " Installing nkf... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### lsof ####
set +e

CHK_lsof=$(dpkg -l | grep lsof | head -n 1 | cut -d " " -f3)

set -e

if [ "$CHK_lsof" = "lsof" ]; then
        echo " lsof is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
	echo ''
        echo " Installing lsof..."
        sudo apt -o Acquire::Retries=3 install -y -q lsof
        wait
        echo " Installing lsof... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### bc ####
set +e

CHK_bc=$(dpkg -l | grep bc | head -n 1 | cut -d " " -f3)

set -e

if [ "$CHK_bc" = "bc" ]; then
         echo " bc is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
	echo ''
        echo " Installing bc..."
        sudo apt -o Acquire::Retries=3 install -y -q bc
        wait
        echo " Installing bc... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### pmount ####
set +e

CHK_pmount=$(dpkg -l | grep pmount | head -n 1 | cut -d " " -f3)

set -e

if [ "$CHK_pmount" = "pmount" ]; then
        echo " pmount is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
        echo ''
        echo " Installing pmount..."
        sudo apt -o Acquire::Retries=3 install -y -q pmount
        wait

	sudo cp ./99-usb-mount.rules /etc/udev/rules.d/99-usb-mount.rules	#USB-drive auto-mount setting1

	sudo cp ./usb-mount@.service /etc/systemd/system/usb-mount@.service	#Daemonaize udiskie
	sudo systemctl daemon-reload						#
        echo " Installing pmount... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### getcover ####
if [ -e /usr/local/bin/getcover ]; then
        echo " getcover is already installed. Installer will skip this process.." | sudo tee -a /${bootDIR}/mute_log
else
        echo ''
        echo " Installing getcover..."

		sudo gcc -o getcover getcover.c
        sudo mv ./getcover /usr/local/bin/getcover

        echo " Installing getcover... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
fi

#### Install DLNA & AirPlay Renderers (1.20) 	####################

echo ''
echo ' 5 - Install Media Renderers' | sudo tee -a /${bootDIR}/mute_log

## DLNA Renderer (UpMPDcli) 
echo " Installing DLNA Renderer..."

	# Get OS Code-name
	OS_CODENAME=$(lsb_release -sc)
	echo "Detected OS: ${OS_CODENAME}"

	# Install UpMPDcli and Setting
	if [ "${OS_CODENAME}" = "bullseye" ] || [ "${OS_CODENAME}" = "bookworm" ] || [ "${OS_CODENAME}" = "trixie" ]; then #Version Check
		# Import repository key & Keylist
	    sudo curl -L \
	    https://www.lesbonscomptes.com/pages/lesbonscomptes.gpg \
	    -o /usr/share/keyrings/lesbonscomptes.gpg

	    sudo curl -L \
 	   "https://www.lesbonscomptes.com/upmpdcli/pages/upmpdcli-${OS_CODENAME}.sources" \
 	   -o /etc/apt/sources.list.d/upmpdcli.sources

		# Install upmpdcli
	    sudo apt update
	    sudo apt -o Acquire::Retries=3 install -y -q upmpdcli

    	# Replace unit file
    	if [ -f /usr/lib/systemd/system/upmpdcli.service ]; then
    	    sudo rm /usr/lib/systemd/system/upmpdcli.service
    	fi
    	sudo cp ./upmpdcli.service /etc/systemd/system/upmpdcli.service
		sudo cp ./upmpdcli.conf /etc/upmpdcli.conf
		sudo cp ./mute_icon.png /usr/share/upmpdcli/mute_icon.png

		#Enable and Start
		echo " Enabling and Starting DLNA Renderer..."
        sudo systemctl daemon-reload
        sudo systemctl enable --now upmpdcli

		echo " Installing DLNA Renderer... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null
	else
    	echo " Skipping UpMPDcli: Unsupported OS version." | sudo tee -a /${bootDIR}/mute_log
	fi

# Shairport-sync
echo " Installing AirPlay Reciever..."

	# Install shair-port-sync
	sudo apt -o Acquire::Retries=3 install -y -q shairport-sync

	# AirPlay (Shairport-sync) settings
	sudo systemctl stop shairport-sync

	# Remove old init script if exists
	if [ -f /etc/init.d/shairport-sync ]; then
	    sudo rm /etc/init.d/shairport-sync
	fi

	# Copy config and systemd service files from the same directory
	sudo cp ./shairport-sync.conf /etc/shairport-sync.conf
	sudo cp ./shairport-sync.service /etc/systemd/system/shairport-sync.service	

	# Enable and Start
	echo " Enabling and Starting AirPlay Reciever..."
	sudo systemctl daemon-reload
	sudo systemctl enable --now shairport-sync

	echo " Installing AirPlay Reciever... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

echo " Enabling and Starting Media Renderers... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null


#### Install [ mute ] Source		####################

echo ''
echo " 6 - Copy [ mute ] source" | sudo tee -a /${bootDIR}/mute_log

set +e

hostname=$(hostname)

set -e

if [ -e /var/www/cgi-bin/etc/mute.conf ]; then

    echo " [ mute ] source exists, you can use [ mute ] already." | sudo tee -a /${bootDIR}/mute_log
	echo " To control [ mute ], access \" ${hostname}.local \" via web browser from your PC/Tablet."
    echo ''
    echo ' --------  mute install Finished. --------' | sudo tee -a /${bootDIR}/mute_log > /dev/null

else

	echo " Copying [ mute ] source..."
	sudo chmod -R 777 /var/www
	sudo cp -RT ./www /var/www
	wait
    sudo chmod -R 755 /var/www

 	## Install Update-Check Service & Timer (1.06)
	sudo mv /var/www/cgi-bin/Update/updchk.service /etc/systemd/system/updchk.service
	sudo mv /var/www/cgi-bin/Update/updchk.timer /etc/systemd/system/updchk.timer
	sudo chmod 644 /etc/systemd/system/updchk.service /etc/systemd/system/updchk.timer
	
    sudo systemctl daemon-reload
	sudo systemctl --now enable updchk.service > /dev/null
	sudo systemctl --now enable updchk.timer > /dev/null

	## Install Start-Up Sound Service (1.07b)
	sudo mv /var/www/cgi-bin/Start/startUpSound.service /etc/systemd/system/startUpSound.service
    sudo chmod 644 /etc/systemd/system/startUpSound.service

	sudo systemctl daemon-reload
	sudo systemctl enable startUpSound.service > /dev/null

    echo " Copying [ mute ] source... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	#### Finalize			####################

	echo ''
	echo " 7 - Finalize - Clean up the sources and this script" | sudo tee -a /${bootDIR}/mute_log
	echo " Finalizing Install..."

	sudo sed -i -e "s/ver.*/ver.${VER}/" ./motd && sudo cp ./motd /etc/motd
    echo " Finalizing Install... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	echo ' Fixing alsa-state daemon...'
	 sudo systemctl stop alsa-state.service
	 sudo cp ./alsa-state.service /lib/systemd/system/alsa-state.service
	 wait
	 sudo systemctl daemon-reload
	 wait
	 sudo systemctl start alsa-state.service
    echo " Fixing alsa-state daemon... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	echo ' Turned off the on-board Audio (Headphone).'
	 sudo sed -i -e "s/dtparam=audio=on/#dtparam=audio=on/" /${bootDIR}/config.txt
	 wait
    echo " Turned off the on-board Audio (Headphone)... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	echo ' Turned off the HDMI port.'
	 sudo sed -i -e "s/dtoverlay=vc4-kms-v3d/#dtoverlay=vc4-kms-v3d/" -e "s/max_framebuffers=2/#max_framebuffers=2/" /${bootDIR}/config.txt
	 wait
    echo " Turned off the HDMI port... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	echo ' Prevent scanning I2C HAT EEPROM.'
	echo 'force_eeprom_read=0' | sudo tee -a /${bootDIR}/config.txt > /dev/null
    echo " Prevent scanning I2C HAT EEPROM... Done" | sudo tee -a /${bootDIR}/mute_log > /dev/null

    sudo rm -Rf ../mute_setting
    wait
    echo " Removed mute_setting files." | sudo tee -a /${bootDIR}/mute_log

	echo ''
    echo " [ mute ] is installed successfully, automatically reboots."
    echo " To control [ mute ], access \" ${hostname}.local \" via web browser from your PC/Tablet after rebooting."
    echo ''

    DATE=$(date)
	echo " --------  mute install Finished. ${DATE} --------" | sudo tee -a /${bootDIR}/mute_log > /dev/null

	echo ' Rebooting...'
	echo ''

	sudo reboot
fi

exit 0
