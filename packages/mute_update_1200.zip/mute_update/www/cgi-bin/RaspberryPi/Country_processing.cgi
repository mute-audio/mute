#!/bin/bash

# Country_processing.cgi	                       #
# (C)2025 kitamura_design <kitamura_design@me.com> #

query=$(date +%Y%m%d%I%M%S)

COUNTRY=$(echo ${QUERY_STRING} | cut -d '=' -f 2 | nkf -Ww --url-input | cut -d '+' -f 1)

#HTML
echo "Content-type: text/html; charset=utf-8"
echo

echo "<!DOCTYPE html>"
echo "<html>"

echo  "<head>"
echo    "<link rel=\"stylesheet\" type=\"text/css\" href=\"/css/main.css\">"
echo    "<meta http-equiv=\"refresh\" content=\"0; URL=/cgi-bin/RaspberryPi/Country_Select.cgi?${COUNTRY}\">"
echo    "<script>"

echo    "function uiLock(){"
echo      "target = parent.document.getElementById(\"sidebar\");"
echo      "if (target != null){"
echo         "target.className = \"sidebar-ui-lock\";"
echo      "}"
echo    "}"

echo    "function uiUnlock(){"
echo      "target = parent.document.getElementById(\"sidebar\");"
echo      "if (target != null){"
echo         "target.className = \"sidebar-ui-unlock\";"
echo      "}"
echo    "}"

echo  "</script>"
echo  "</head>"

echo "<body onLoad=\"uiLock()\" onunload=\"uiUnlock()\">"

#### Loading Screen
   cat <<HTML
   <div id="loading-top2">
     <div class="loader">
        <div class="loadingtext">Setting WiFi Country [ ${COUNTRY} ] ...</div>
        <div class="progress-bar-base">
        <div class="progress-value-loading"></div>
        </div>
     </div>
   </div>
HTML

echo "</body>"
echo "</html>"
